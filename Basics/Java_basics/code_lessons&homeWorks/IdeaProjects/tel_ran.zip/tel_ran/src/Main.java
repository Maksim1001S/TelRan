import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("send your name");
//
//        String name = scanner.nextLine();
//        System.out.println("Hello " + name + "!");
//
//        String val_1 = "12";
//        String val_2 = "324";
//        System.out.println(Integer.parseInt(val_1) + Integer.parseInt(val_2));


        File file = new File("src/text.txt");
        Scanner scann = new Scanner(file);
        System.out.println(scann.nextLine());
    }

}